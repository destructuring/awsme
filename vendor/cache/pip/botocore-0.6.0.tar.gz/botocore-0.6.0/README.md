botocore
========

[![Build Status](https://travis-ci.org/boto/botocore.png?branch=develop)](https://travis-ci.org/boto/botocore)

A low-level interface to a growing number of Amazon Web Services.  The
botocore package is the foundation for [AWS-CLI](https://github.com/aws/aws-cli).

[Documentation](https://botocore.readthedocs.org/en/latest/)
