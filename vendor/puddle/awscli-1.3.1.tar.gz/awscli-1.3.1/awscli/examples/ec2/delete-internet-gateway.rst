**To delete an Internet gateway**

This example deletes the specified Internet gateway.

Command::

  aws ec2 delete-internet-gateway --internet-gateway-id igw-c0a643a9

Output::

  {
      "return": "true"
  }