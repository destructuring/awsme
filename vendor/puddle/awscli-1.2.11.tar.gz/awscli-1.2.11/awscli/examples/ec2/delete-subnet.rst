**To delete a subnet**

This example deletes the specified subnet.

Command::

  aws ec2 delete-subnet --subnet-id subnet-9d4a7b6c

Output::

  {
      "return": "true"
  }