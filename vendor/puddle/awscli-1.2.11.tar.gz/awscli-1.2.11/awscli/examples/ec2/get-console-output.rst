**To get the console output**

This example gets the console ouput for the specified Linux instance.

Command::

  aws ec2 get-console-output --instance-id i-10a64379

Output::

  {
      "InstanceId": "i-10a64379",
      "Timestamp": "2013-07-25T21:23:53.000Z",
      "Output": "..."
  }

