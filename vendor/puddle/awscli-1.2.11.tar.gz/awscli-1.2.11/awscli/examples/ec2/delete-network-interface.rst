**To delete a network interface**

This example deletes the specified network interface.

Command::

  aws ec2 delete-network-interface --network-interface-id eni-e5aa89a3

Output::

  {
      "return": "true"
  }